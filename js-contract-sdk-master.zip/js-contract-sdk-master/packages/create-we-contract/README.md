# create-we-contract

Quickstart with Waves Enterprise platform contracts

## Prerequisites

* Node.js

## Getting Started

Run following command for create first project with default configuration

```sh
npm create we-contract MyContract
```

Options:

* `-t path-to-folder` - specify folder to scaffold project, default we-contract-starter
* `-n package-name` - specify name in package.json of your project

## License

This project is licensed under the [MIT License](LICENSE).

