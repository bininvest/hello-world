#!/bin/sh

eval $SET_ENV_CMD
node dist/index.js
