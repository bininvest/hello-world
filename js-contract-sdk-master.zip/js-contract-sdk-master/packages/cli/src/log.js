function info(...args) {
  console.info(...args);
}


module.exports = {
  info
}