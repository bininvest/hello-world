# Change Log

All notable changes to this project will be documented in this file.
See [Conventional Commits](https://conventionalcommits.org) for commit guidelines.

## [0.0.3](https://github.com/waves-enterprise/js-contract-sdk/compare/@wavesenterprise/contract-cli@0.0.2...@wavesenterprise/contract-cli@0.0.3) (2022-07-26)

**Note:** Version bump only for package @wavesenterprise/contract-cli
