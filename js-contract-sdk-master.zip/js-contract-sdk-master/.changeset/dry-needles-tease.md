---
"@wavesenterprise/contract-core": patch
"@wavesenterprise/contract-cli": patch
"create-we-contract": patch
---

Native tokens compatibility
