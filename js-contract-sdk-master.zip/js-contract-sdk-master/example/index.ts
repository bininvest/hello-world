import 'reflect-metadata'

import { initContract } from '../packages/contract-core/src'

initContract({ contractPath: './contract', concurrencyLevel: 8 })
